// lib/views/screens/warehouse/archive_tab_content.dart
//
// تبويب "Archive" بشاشة Request List — مربوط بالكامل الآن:
//   GET /workers/disposals  (عبر DestructionController.archivedDisposals)
// كل طلب حالته غير pending/awaiting_approval/in_review بيظهر هون.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../controllers/destruction_controller.dart';
import '../../../models/destruction_model.dart';
import '../../../utils/constants.dart';

class ArchiveTabContent extends StatelessWidget {
  const ArchiveTabContent({super.key});

  Color _statusColor(Disposal d) {
    if (d.isRejected) return AppColors.red;
    if (d.isApproved) return const Color(0xFF4CAF50);
    return AppColors.navy;
  }

  String _statusLabel(Disposal d) {
    if (d.isRejected) return 'Rejected';
    if (d.isApproved) return 'Approved';
    return d.status ?? 'Archived';
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<DestructionController>(
      builder: (context, controller, _) {
        if (controller.isLoadingList && controller.disposals.isEmpty) {
          return const Center(child: CircularProgressIndicator());
        }

        if (controller.listError != null && controller.disposals.isEmpty) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.error_outline,
                      color: Colors.redAccent, size: 36),
                  const SizedBox(height: 12),
                  Text(controller.listError!, textAlign: TextAlign.center),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: () => controller.fetchDisposals(),
                    child: const Text('Retry'),
                  ),
                ],
              ),
            ),
          );
        }

        final items = controller.archivedDisposals;

        if (items.isEmpty) {
          return const Center(
            child: Text(
              'No archived destruction requests',
              style: TextStyle(
                fontFamily: 'Inter',
                fontSize: 15,
                color: Colors.black54,
              ),
            ),
          );
        }

        return RefreshIndicator(
          onRefresh: () => controller.fetchDisposals(),
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
            itemCount: items.length,
            itemBuilder: (context, index) {
              final d = items[index];
              return Container(
                margin: const EdgeInsets.only(bottom: 16),
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: AppColors.navy.withOpacity(0.3),
                    width: 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.06),
                      blurRadius: 6,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _statusLabel(d),
                      style: TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        color: _statusColor(d),
                      ),
                    ),
                    const SizedBox(height: 8),
                    _buildRow(Icons.inventory_2_outlined, d.displayTitle),
                    _buildRow(Icons.shopping_cart_outlined,
                        'Qty: ${d.quantity} Units'),
                    if (d.damageReason != null)
                      _buildRow(
                          Icons.warning_amber_rounded, d.damageReason!),
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildRow(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 18, color: Colors.black54),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                fontFamily: 'Inter',
                fontSize: 14,
                color: Colors.black87,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
